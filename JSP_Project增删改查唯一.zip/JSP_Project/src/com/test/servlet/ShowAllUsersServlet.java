package com.test.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.entity.User;
import com.test.service.IUserService;
import com.test.service.impl.UserServiceImpl;

/**
 * Servlet implementation class ShowAllUsersServlet
 */
@WebServlet("/ShowAllUsersServlet")
public class ShowAllUsersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/** 
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 多态形式创建UserServiceImpl对象
		IUserService User = new UserServiceImpl();
		// 使用方法
		List<User> queryAllUsersService = User.queryAllUsersService();
		/*
		 * for (int i = 0; i < queryAllUsersService.size(); i++) {
		 * System.out.println(queryAllUsersService.get(i)); }
		 */
		// 把接受到的数组放入request对象中

		//将所有用户集合储存request作用域，在满足要求的情况下，范围越小越好
		request.getSession().setAttribute("AllUsers", queryAllUsersService);
		//根据返回结果，跳转页面ShowUsers.jsp
		//因为将集合保存到request作用域中，在一次请求中有效
		response.sendRedirect("showAllUsers.jsp");
	}

}
