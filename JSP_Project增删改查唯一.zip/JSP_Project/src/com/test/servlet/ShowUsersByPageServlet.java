package com.test.servlet;

import java.io.IOException;
import java.util.List;
import java.util. *;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.IUserDao;
import com.test.dao.impl.UserDaoImpl;
import com.test.entity.PageBean;
import com.test.entity.User;
import com.test.service.IUserService;
import com.test.service.impl.UserServiceImpl;
/**
 * 处理分页显示用户
 */
/**
 * Servlet implementation class ShowUsersByPageServlet
 */
@WebServlet("/ShowUsersByPageServlet")
public class ShowUsersByPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=utf-8");
		
		IUserDao page = new UserDaoImpl();
		//获取数据总数
		int totalCount =page.getTotalCount();
		//页面大小    显示数据条数
		int pageSize=4;//用户自定义
		// 计算总页数
		int totalPage = totalCount % pageSize == 0 ? totalCount / pageSize : totalCount / pageSize + 1;
		//当前页
		int currentPage =1;//用户自定义
		//获取页面发送的请求参数
		if ((request.getParameter("currentPage") != null)&&request.getParameter("currentPage") != "") {
			// 转换为int类型
			currentPage = Integer.parseInt(request.getParameter("currentPage"));
		}
		//总页数
		//总页数  计算  总页数  = 数据总数%页面大小==0？数据总数/页面大小：数据总数/页面大小+1；
		// 创建对象并初始化
		PageBean pagebean = new PageBean(totalCount, pageSize, totalPage, currentPage,
				page.queryAllUserByPage(currentPage, pageSize));
		System.out.println(pagebean);
		// 保存于request对象里面
		request.getSession().setAttribute("pageData", pagebean);
	//根据返回结果，跳转页面  showUsers.jsp
		response.sendRedirect("showUsers.jsp");
	
	}
	
}
 