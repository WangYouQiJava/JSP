package com.test.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.service.IUserService;
import com.test.service.impl.UserServiceImpl;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String a= (String)request.getSession().getAttribute("oldname");
		String b= request.getParameter("upname");
		String c= request.getParameter("uppwd");
		System.out.println(a+","+b+","+c);
		//request.getSession().setAttribute("oldname", a);
		IUserService ser = new UserServiceImpl();
	ser.UpDateUser(b, c, a);
	request.setAttribute("oldname", null);

		// 判断是否创建成功
		// 删除成功后跳转显示页面
		// 失败跳转失败页面
		response.sendRedirect("ShowUsersByPageServlet");
		//response.sendRedirect("LoginServlet");
		}
	
	

}
