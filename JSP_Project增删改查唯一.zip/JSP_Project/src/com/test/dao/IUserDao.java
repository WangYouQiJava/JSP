package com.test.dao;

import java.util.List;

import com.test.entity.User;
/**
 * 数据访问层
 *
 */
public interface IUserDao {
	//登录
	boolean loginUser(String uname, String upwd);
	//注册
	boolean regist(User user);
	//删除根据Uname删除用户
	boolean Delete(String Uname);
	//数据总数
	int getTotalCount();
	//分页显示所有用户
	List<User> queryAllUserByPage(int currentPage,int pageSize);
	//更改
	boolean UpDateUser(String uname,String upwd,String old);
	
	
	//查询用户名是否存在
	boolean checkUser(String name);
	//显示所有用户
	List<User> queryAllUsers();
	
}
