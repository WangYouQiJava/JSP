package com.test.service.impl;

import java.util.List;

import com.test.dao.IUserDao;
import com.test.dao.impl.UserDaoImpl;
import com.test.entity.User;
import com.test.service.IUserService;

public class UserServiceImpl implements IUserService {
	// 创建dao层实现类的对象
	IUserDao userDao=new UserDaoImpl();
	/**
	 * 注册/增加
	 */
	@Override
	public boolean registService(User user) {
		//创建数据访问层的对象 IUserDao    UserDaoimpl
		return userDao.regist(user);//调用数据访问层
	}
	/**
	 * 登录
	 */
	@Override
	public boolean loginService(String name,String upwd) {
		return userDao.loginUser(name, upwd);//调用数据访问层
	}
	 
	
	/**
	 * 分页查询用户数据
	 */
	@Override
	public List<User> queryUsersByPageService(int currentPage, int pageSize) {
		return userDao.queryAllUserByPage(currentPage, pageSize);
	}
	/**
	 * 查询数据总条数
	 */
	@Override
	public int getTotalCountService() {
		return userDao.getTotalCount();
	}
	/**
	 * 删除
	 */
	@Override
	public boolean Delete(String Uname) {
		//根据Uname删除用户
		return userDao.Delete(Uname);
	}
	/**
	 * 更改用户
	 */
	@Override
	public boolean UpDateUser(String uname, String upwd,String old) {
		return userDao.UpDateUser(uname, upwd,old);
	}
	
	/**
	 * 判断是否存在
	 */
	@Override
	public boolean checkuser(String name) {
		return userDao.checkUser(name);
	}
	
	
	
	/**
	 * 查询所有用户信息方法
	 */
	@Override
	public List queryAllUsersService() {
		//IUserDao userDao = new UserDaoImpl();
		//List<User> userList = userDao.queryAllUsers();
		return userDao.queryAllUsers();
	}
	
}
