DROP TABLE IF EXISTS librarydb7;
CREATE table librarydb7(
	#uid INT auto_increment PRIMARY KEY,
	uname VARCHAR(50),
	mimi VARCHAR(50),
	age INT 
	#address VARCHAR(100) 
);
DESC librarydb7;
#INSERT librarydb7(uname,mimi) VALUES('张三','123'),('李四','456');





