package com.test.Filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//后台代码
/**
 * Servlet Filter implementation class LoginFilter
 */
@WebFilter("/welcome.jsp")
public class LoginFilter implements Filter {
    /**
     * Default constructor. 
     */
    public LoginFilter() {
        // TODO Auto-generated constructor stub
    	
    }
	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		System.out.println("销毁了");
		// TODO Auto-generated method stub	
	}
	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		System.out.println("***请求处理之前***");
		// 强转
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		// 获取session对象
		HttpSession session = req.getSession();
		// 判断session获取到是否为空，为空则没登录，跳转到登录页 登录
		if ((session.getAttribute("user")) == null) {
			System.out.println("验证失败了");
			resp.sendRedirect("login.jsp");
		}
		// pass the request along the filter chain
		// 继续执行
		// pass the request along the filter chain
		chain.doFilter(request, response);
		System.out.println("***请求处理之后***");
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("初始化了");
		// TODO Auto-generated method stub
		
	}
}
