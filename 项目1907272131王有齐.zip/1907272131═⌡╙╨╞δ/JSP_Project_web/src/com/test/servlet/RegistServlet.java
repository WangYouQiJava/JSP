package com.test.servlet;

import java.io.IOException;
/**
 * 
 * 三成架构  表示层中前台代码
 */
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.dao.impl.UserDaoImpl;
import com.test.entity.User;
import com.test.service.IUserService;
import com.test.service.impl.UserServiceImpl;

import javafx.scene.control.Alert;
@WebServlet(urlPatterns="/RegistServlet")

public class RegistServlet extends HttpServlet{
	protected void service(HttpServletRequest req,HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		HttpSession session = req.getSession();
		PrintWriter out=resp.getWriter();
		String uname=req.getParameter("uname");
		String upwd=req.getParameter("upwd");
		//创建对象并赋值
		User user = new User(uname, upwd);
		//创建对象
		System.out.println(user);
		UserServiceImpl service = new UserServiceImpl();
		boolean flag1 = service.checkuser(uname);
		if ((uname == "") || (upwd == "")){
			req.getRequestDispatcher("registOut.jsp").forward(req, resp);
			}else if(flag1==true) {
				System.out.println("用户名以在数据库中存在");
				req.getSession().setAttribute("resultRegist", "用户名已存在，请重新注册");
				resp.sendRedirect("regist.jsp");
			}else {
				System.out.println("用户名没有存在数据库中");
				boolean flag =service.registService(user);
				//处理数据
				System.out.println(flag);
				if (flag == true) {
					req.getSession().setAttribute("resultLogin", "注册成功，前往登录页面");
					req.getSession().setAttribute(uname, upwd);
					req.getRequestDispatcher("login.jsp").forward(req,resp);
				}
		}
	}
}
