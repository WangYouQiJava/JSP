package com.test.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.IUserDao;
import com.test.dao.impl.UserDaoImpl;
import com.test.entity.User;
import com.test.service.IUserService;
import com.test.service.impl.UserServiceImpl;

/**
 * 登录处理页面 Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
		// 设置中文编码
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		// 获取数据
		String uname = request.getParameter("uname");
		String upwd = request.getParameter("upwd");
		// 封装数据
		User user = new User(uname, upwd);
		
		System.out.println(user);
		// 调用下层服务 接口 对象名 = new 实现类 （）； 多态
		IUserDao userdao = new UserDaoImpl();
		//IUserService service = new UserServiceImpl();
		//返回值
		boolean flag = userdao.loginUser(user.getUname(), user.getUpwd());
		// 处理数据
		System.out.println(flag);
		if (flag == true) {
			request.getSession().setAttribute("User1",user);
			request.getRequestDispatcher("PageAdmin.jsp").forward(request, response);
		} else {
			response.sendRedirect("loginOut.jsp");
		}
	}
}
