package com.test.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.service.IUserService;
import com.test.service.impl.UserServiceImpl;

/**
 * Servlet implementation class deleteServlet
 */
@WebServlet("/deleteServlet")
public class deleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String a= req.getParameter("Userid");
		System.out.println("qqq"+a);

		// 创建对象调用下层服务
		IUserService ser = new UserServiceImpl();
		// 判断是否创建成功
		boolean result = ser.Delete(a);
		// 删除成功后跳转显示页面
		if (result) {
			req.getSession().setAttribute("result", "1");
			resp.sendRedirect("ShowUsersByPageServlet");
		} else {
			// 失败跳转失败页面
			resp.sendRedirect("a.jsp");
		}

	}
}
