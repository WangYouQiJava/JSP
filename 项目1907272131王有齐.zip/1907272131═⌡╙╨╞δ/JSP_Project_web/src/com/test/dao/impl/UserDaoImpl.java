package com.test.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.test.dao.IUserDao;
import com.test.entity.User;

public class UserDaoImpl implements IUserDao {
	/**
	 * 登录
	 */
	@Override
	public boolean loginUser(String uname, String upwd) {
		// 声明jdbc对象
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean flag = false;
		try {
			// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 获取连接
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb7", "root", "200191");
			// 获取预编译的数据库操作对象
			String sql = "SELECT * FROM librarydb7 WHERE uname=? AND mimi=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, uname);
			ps.setString(2, upwd);
			// 执行sql
			rs = ps.executeQuery();
			// 处理结果集
			if (rs.next()) {
				flag = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭资源
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return flag;
	}
	/**
	 * 注册
	 */
	@Override
	public boolean regist(User user) {
		// 声明jdbc对象
		Connection con = null;
		PreparedStatement ps = null;
		int rs = 0;
		boolean flag = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			// 获取连接
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb7", "root", "200191");
			// 获取预编译的数据库操作对象
			String sql = "INSERT librarydb7 (uname,mimi) VALUES(?,?)";
			if (user.getUname().length()>20 || user.getUpwd().length()<1) {
				flag = false;
			} else {
				flag = true;
				ps = con.prepareStatement(sql);
				ps.setString(1, user.getUname());
				ps.setString(2, user.getUpwd());
				rs = ps.executeUpdate();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return flag;
	}

	/**
	 * 查询，用户名不能重复
	 */
	@Override
	public boolean checkUser(String name) {
		// 声明jdbc对象
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		boolean flag = false;
		try {
			// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 标记是否有该用户
			// 获取连接
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb7", "root", "200191");
			// 获取预编译的数据库操作对象
			String sql = "select * from librarydb7 where uname = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, name);
			// 执行sql
			rs = ps.executeQuery();
			// 处理结果集
			if (rs.next()) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭资源
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		return flag;
	}

	/**
	 * 删除
	 */
	@Override
	public boolean Delete(String Uname) {
		Connection con = null;
		PreparedStatement ps = null;
		String sql = "DELETE FROM librarydb7 WHERE uname=?";
		try {// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 标记是否有该用户
			// 获取连接
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb7", "root", "200191");
			// 获取预编译的数据库操作对象
			ps = con.prepareStatement(sql);
			ps.setString(1, Uname);
			
			int counts = ps.executeUpdate();
			System.out.println(counts);
			if (counts > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭资源
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	/**
	 * 更改数据（改）
	 */
	public boolean UpDateUser(String uname, String upwd, String old) {
		Connection con = null;
		PreparedStatement ps = null;
		boolean flag = false;
		try {
			// 加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			// 获取连接
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb7", "root", "200191");
			// 获取预编译的数据库操作对象
			// 获取预编译的数据库操作对象
			String sql = "UPDATE librarydb7 SET uname=?,mimi=?  WHERE uname=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, uname);
			ps.setString(2, upwd);
			ps.setString(3, old);
			// 执行sql
			int counts = ps.executeUpdate();
			// 处理结果集
			if (counts > 0) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭资源
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		return flag;

	}
	/**
	 * 分页显示所有用户
	 * 查询当前页数数据集合
	 */
	@Override
	public List<User> queryAllUserByPage(int currentPage,int pageSize) {
		// 计算起始条数
		//int startnum = (currentPage - 1) * pageSize;
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<User> userList = new ArrayList<User>();
		//User u = null;
		try{
			//加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			//标记是否有该用户
			//获取连接
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb7", "root", "200191");
			//获取预编译的数据库操作对象
			String sql = "select * from librarydb7 limit ?,?";
			ps = con.prepareStatement(sql);	
			//插入数据
			ps.setInt(1, (currentPage-1)*pageSize);
			ps.setInt(2, pageSize);
			//处理结果集
			rs = ps.executeQuery();
			
			while(rs.next()) {
				String uname = rs.getString("uname");
				String upwd = rs.getString("mimi");
				User user = new User(uname, upwd);
				userList.add(user);
			}

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			//关闭资源
			if(rs!=null){
				try{
					rs.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			if(ps!=null){
				try{
					ps.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			if(con!=null){
				try{
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		return userList;
	}
	/**
	 * 获取数据总数
	 */
	@Override
	public int getTotalCount() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		//计数
		int count = 0;
		try{
			//加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			//标记是否有该用户
			//获取连接
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb7", "root", "200191");
			//获取预编译的数据库操作对象
			String sql = "select count(*) from librarydb7";
			ps = con.prepareStatement(sql);	
			//执行sql
			rs = ps.executeQuery();
			//处理结果集
			if(rs.next()) {
				count = rs.getInt(1);//结果集中第一列
				return count;
			}

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			//关闭资源
			if(rs!=null){
				try{
					rs.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			if(ps!=null){
				try{
					ps.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			if(con!=null){
				try{
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		return count;
	}
	/**
	 * 显示所有用户
	 */
	@Override
	public List<User> queryAllUsers() {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		//创建集合对象
		List<User> userList = new ArrayList<>();
		try{
			//加载驱动
			Class.forName("com.mysql.jdbc.Driver");
			//标记是否有该用户
			//获取连接
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb7", "root", "200191");
			//获取预编译的数据库操作对象
			String sql = "SELECT * FROM librarydb7";
			//获取预编译的数据库操作对象
			ps = con.prepareStatement(sql);	
			//执行sql
			rs = ps.executeQuery();
			//处理结果集
			while(rs.next()) {
				String uname = rs.getString("uname");
				String upwd = rs.getString("mimi");
				//将结果集中的字段封装的用户User对象中
				User user = new User(uname,upwd);
				userList.add(user);
			}

		}catch(Exception e){
			e.printStackTrace();
		}finally{
			//关闭资源
			if(rs!=null){
				try{
					rs.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			if(ps!=null){
				try{
					ps.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
			if(con!=null){
				try{
					con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		return userList;
	}
	
}
