package com.test.entity;

import java.util.List;

public class PageBean {
	// 数据总数 查数据库
	private int totalCount;
	// 页面大小 用户自定义
	private int pageSize;
	// 总页数 计算
	private int totalPage;
	// 当前页 用户自定义
	private int currentPage;
	// 当前页的数据集合 查询数据库
	private List<User> users;

	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public int getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public List<User> getUsers() {
		return users;
	}
	public void setUsers(List<User> users) {
		this.users = users;
	}
	public PageBean(int totalCount, int pageSize, int totalPage, int currentPage, List<User> users) {
		super();
		this.totalCount = totalCount;
		this.pageSize = pageSize;
		this.totalPage = totalPage;
		this.currentPage = currentPage;
		this.users = users;
	}
	public PageBean() {
		super();
	}
	@Override
	public String toString() {
		return "PageBean [totalCount=" + totalCount + ", pageSize=" + pageSize + ", totalPage=" + totalPage
				+ ", currentPage=" + currentPage + ", users=" + users + "]";
	}
	}
