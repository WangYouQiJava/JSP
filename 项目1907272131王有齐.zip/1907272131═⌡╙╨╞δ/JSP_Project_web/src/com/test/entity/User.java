package com.test.entity;
/**
 * 
 * 模型层
 * @author 
 *
 */
public class User{
	private String uname;
	private String upwd;
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpwd() {
		return upwd;
	}
	
	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}
	public User() {
		super();
	}
	public User(String uname, String upwd) {
	//	super();
		this.uname = uname;
		this.upwd = upwd;
	}
	@Override
	public String toString() {
		return "User [uname=" + uname + ", upwd=" + upwd + "]";
	}
	
}