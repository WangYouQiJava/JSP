package com.test.service;

import java.util.List;

import com.test.entity.User;
/**
 * 业务逻辑层 ，又叫service层
 * @author 
 *
 */
public interface IUserService {
	//登录
    boolean loginService(String name,String upwd);
	//注册
    boolean registService(User user);
 	// 根据uname删除用户
 	boolean Delete(String Uname);
 	//查询数据页的数据集合
	List<User> queryUsersByPageService(int currentPage, int pageSize);
	//查询数据总数
	int getTotalCountService();
	// 更新是否成功
	boolean UpDateUser(String uname,String upwd,String old);

	
	
	//显示所有用户
	List<User> queryAllUsersService();

	// 查询用户名是否存在
 	boolean checkuser(String name);

	}
