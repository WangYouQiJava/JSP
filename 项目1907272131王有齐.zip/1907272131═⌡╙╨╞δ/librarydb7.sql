/*
Navicat MySQL Data Transfer

Source Server         : wyq_SQL
Source Server Version : 50726
Source Host           : localhost:3306
Source Database       : librarydb7

Target Server Type    : MYSQL
Target Server Version : 50726
File Encoding         : 65001

Date: 2020-12-25 17:48:16
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for librarydb7
-- ----------------------------
DROP TABLE IF EXISTS `librarydb7`;
CREATE TABLE `librarydb7` (
  `uname` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimi` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of librarydb7
-- ----------------------------
INSERT INTO `librarydb7` VALUES ('e', 'e', null);
INSERT INTO `librarydb7` VALUES ('1', '1', null);
INSERT INTO `librarydb7` VALUES ('11', '11', null);
INSERT INTO `librarydb7` VALUES ('33', '33', null);
INSERT INTO `librarydb7` VALUES ('张三', '123', null);
INSERT INTO `librarydb7` VALUES ('a', 'a', null);
INSERT INTO `librarydb7` VALUES ('5', '5', null);
INSERT INTO `librarydb7` VALUES ('3', '3', null);
INSERT INTO `librarydb7` VALUES ('d', 'd', null);
INSERT INTO `librarydb7` VALUES ('c', 'c', null);
INSERT INTO `librarydb7` VALUES ('r', 'r', null);
INSERT INTO `librarydb7` VALUES ('y', 'y', null);
INSERT INTO `librarydb7` VALUES ('p', 'p', null);
INSERT INTO `librarydb7` VALUES ('f', 'f', null);
INSERT INTO `librarydb7` VALUES ('ff', 'ff', null);
INSERT INTO `librarydb7` VALUES ('王', '王', null);
INSERT INTO `librarydb7` VALUES ('gg', 'gg', null);
INSERT INTO `librarydb7` VALUES ('王有齐', '123', null);
